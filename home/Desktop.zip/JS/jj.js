function over(obj) {
    obj.src = "C:/Users/Administrator/Desktop/아메리카노.png";
}

function double(obj) {
    obj.src = "C:/Users/Administrator/Desktop/아메리카노.png";
}